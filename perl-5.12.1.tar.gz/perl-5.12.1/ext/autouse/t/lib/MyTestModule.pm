package MyTestModule;
use strict;

sub test_function {
  return 'works';
}

1;
